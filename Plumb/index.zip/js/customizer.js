/**
 * File customizer.js.
 *
